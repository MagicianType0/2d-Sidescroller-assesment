﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
    public AudioMixer mixer;
    public Slider slider;
    public AudioSource sfx;
    public AudioClip cymbals;
    public void SetExposedParamMusicVolume(float value)
    {
        mixer.SetFloat("MusicVolume", value); //change Game volume
    }

    public void SetExposedParamSFX(float value)
    {
        mixer.SetFloat("SFXVolume", value); //change Sfx Volume
    }
    public void SetExposedParamMasterVolune(float value)
    {
        mixer.SetFloat("MasterVolume", value); //change Master volume
    }
}
