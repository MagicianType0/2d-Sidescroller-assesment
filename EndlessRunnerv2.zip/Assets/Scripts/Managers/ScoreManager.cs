﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public Text scoreText;
    public Text HighscoreText;

    public float scoreCount;
    public float highscoreCount;

    public float pointsPerSecond;

    public bool scoreIncreasing;
    void Start()
    {
        if(PlayerPrefs.GetFloat("HighScore") != null)
        {
            highscoreCount = PlayerPrefs.GetFloat("HighScore");
        }
    }

    void Update()
    {
        if (scoreIncreasing)
        {
            scoreCount += pointsPerSecond * Time.deltaTime;

        }

        if (scoreCount > highscoreCount)
        {
            highscoreCount = scoreCount;
            PlayerPrefs.SetFloat("HighScore", highscoreCount);
        }

        scoreText.text = "Score: " + Mathf.Round (scoreCount);
        HighscoreText.text = "High score: " + Mathf.Round (highscoreCount);
    }
    public void addScore(int pointsToAdd)
    {
        scoreCount += pointsToAdd;
    }
}
