﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Playermovement thePlayer;

    private Vector3 lastPlayerPosition;
    private float distanceTomove;

    void Start()
    {
        thePlayer = FindObjectOfType<Playermovement>();
        lastPlayerPosition = thePlayer.transform.position;
    }

    void Update()
    {
        distanceTomove = thePlayer.transform.position.x - lastPlayerPosition.x;

        transform.position = new Vector3(transform.position.x + distanceTomove, transform.position.y, transform.position.z);

        lastPlayerPosition = thePlayer.transform.position;
    }
}
