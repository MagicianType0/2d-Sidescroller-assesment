﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbGenerator : MonoBehaviour
{
    public ObjectPooler orbPool;

    public float distanceBetweenOrbs;

    public void SpawnOrbs (Vector3 startPosition)
    {
        GameObject orb1 = orbPool.GetPooledObjects();
        orb1.transform.position = startPosition;
        orb1.SetActive(true);

        GameObject orb2 = orbPool.GetPooledObjects();
        orb2.transform.position = new Vector3(startPosition.x - distanceBetweenOrbs, startPosition.y , startPosition.z);
        orb2.SetActive(true);

        GameObject orb3 = orbPool.GetPooledObjects();
        orb3.transform.position = new Vector3(startPosition.x + distanceBetweenOrbs, startPosition.y, startPosition.z);
        orb3.SetActive(true);
    }
}
