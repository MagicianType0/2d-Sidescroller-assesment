﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpPoint : MonoBehaviour
{
    public int scoreToGive;

    private ScoreManager theScoreManager;

    private AudioSource coinsound;
    void Start()
    {
        theScoreManager = FindObjectOfType<ScoreManager>();

        coinsound = GameObject.Find("Orbsound").GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
       
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.name == "Player")
        {
            theScoreManager.addScore(scoreToGive);
            gameObject.SetActive(false);

            if (coinsound.isPlaying)
            {
                coinsound.Stop();
                coinsound.Play();
            }
            else
            {
                coinsound.Play();
            }

            coinsound.Play();
        }
    }
}
