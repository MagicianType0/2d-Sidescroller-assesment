﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformGenerator : MonoBehaviour
{
    public GameObject thePlatform;
    public Transform generatorPoint;
    public float distanceBetween;

    private float platformWidth;

    public float DistanceBetweenMin;
    public float DistanceBetweenMax;

    //public ObjectPooler theObjectPool;

    private int platformSelector;
    public ObjectPooler[] theObjectPool;
    private float[] platformWidths;

    private float minHeight;
    public Transform maxHeightPoint;
    private float maxHeight;
    public float maxHeightChange;
    private float HeightChange;

    private OrbGenerator theOrbGeneator;
    public float randomOrbThreshHold;
    void Start()
    {
        //platformWidth = thePlatform.GetComponent<BoxCollider2D>().size.x;

        platformWidths = new float[theObjectPool.Length];

        for (int i = 0; i < theObjectPool.Length; i++)
        {
            platformWidths[i] = theObjectPool[i].pooledObject.GetComponent<BoxCollider2D>().size.x;
        }

        minHeight = transform.position.y;
        maxHeight = maxHeightPoint.position.y;

        theOrbGeneator = FindObjectOfType<OrbGenerator>();
    }

    void Update()
    {
        if(transform.position.x < generatorPoint.position.x)
        {
            distanceBetween = Random.Range(DistanceBetweenMin, DistanceBetweenMax);

            platformSelector = Random.Range(0, theObjectPool.Length);

            HeightChange = transform.position.y + Random.Range(maxHeightChange, -maxHeightChange);
            
            if(HeightChange > maxHeight)
            {
                HeightChange = maxHeight;
            }
            else if(HeightChange < minHeight)
            {
                HeightChange = minHeight;
            }

            transform.position = new Vector3(transform.position.x + (platformWidths[platformSelector] / 2) + distanceBetween, HeightChange, transform.position.z);
            
            //Instantiate(/*thePlatform,*/ theObjectPool[platformSelector], transform.position, transform.rotation);

            GameObject newPlatform = theObjectPool[platformSelector].GetPooledObjects();

            newPlatform.transform.position = transform.position;
            newPlatform.transform.rotation = transform.rotation;
            newPlatform.SetActive(true);


            if(Random.Range(0f, 100f) < randomOrbThreshHold)
            {
                theOrbGeneator.SpawnOrbs(new Vector3(transform.position.x, transform.position.y + 1f, transform.position.z));
            }

            transform.position = new Vector3(transform.position.x + (platformWidths[platformSelector] / 2) , transform.position.y, transform.position.z);

        }
    }
}
